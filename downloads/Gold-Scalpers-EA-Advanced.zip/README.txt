GOLD SCALPERS EA ADVANCED  -  Download package
==============================================
Version 3.00

Included:
  - Gold Scalpers EA Advanced.ex5                       (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers EA Advanced - Quick User Guide.pdf    (setup, how it trades, every setting)

What it is:
  A pure XAUUSD (gold) M5 scalper with ONE entry rule. The Slope Direction
  Line is drawn on your chart: GREEN while it is rising, RED while it is
  falling. When the line turns green the EA opens a BUY; when it turns red it
  opens a SELL. The stop sits beyond the candles where the colour changed,
  the target is a fixed 1200 pips ($12.00 on gold), and a break-even move
  protects the trade once it is in profit.

  Everything around that rule is the same engine as Gold Scalpers Pro: daily
  profit target, drawdown lock, prop-firm mode, sessions, news filter,
  loss-streak cooldown, pop-up / push / Telegram alerts, on-chart dashboard,
  manual buttons, pre-flight check and the goldscalpers.com licence.

  It can run on the same account as Gold Scalpers Pro (different magic
  number, separate day-state, separate panel). Use separate charts.

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy
     "Gold Scalpers EA Advanced.ex5" there. The indicator is bundled inside
     the EA - nothing else to install.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M5 chart, drag the EA on, tick "Allow Algo Trading".
     The default settings are already the tuned gold configuration - just
     click OK.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com/licenses
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA shows this same URL so you can
     copy it. It is READ-ONLY - changing it has no effect.
     The check is STRICT: if the URL is not allowed, the EA stays blocked.
     DEMO accounts need activation too - submit the demo login number the
     same way. Nothing runs unlicensed. The EA re-reads the licence list
     every 30 seconds, so activation takes effect within a minute - no
     restart needed.
  5. Activate your licence: submit your MT5 account number on your download
     page (https://goldscalpers.com/thank-you-advancedea) - it is authorized
     automatically within ~2 minutes. Or email it to support@goldscalpers.com.
  6. Read the pre-flight list in the Experts tab once after every attach.
     It tells you PASS / WARN / FAIL for each thing the EA depends on.

How it trades (short version):
  - Signal: on every CLOSED M5 candle the EA compares the line colour of the
    candle that just closed with the one before it. red -> green = BUY,
    green -> red = SELL. Nothing is read from the candle still forming.
  - Stop: beyond the extreme of ColourSLCandles (3) candles at the colour
    turn, plus ColourSLBufferPips (20). Never sent unprotected.
  - Target: ColourTPPips = 1200 pips.
  - Break-even: at BreakEvenPips (300) in profit the stop moves to entry +
    lock. See the note below.
  - Start-up: when attached, the EA alerts the colour already showing and,
    by default, trades it (StartupSlopeTrade = Follow). Set "No trade" for
    alert only.
  - One trade per signal (TradesPerSignal = 1, up to 10), MaxOpenPositions
    = 4, MaxTradesPerDay = 30.

NOTE ON THE BREAK-EVEN LOCK. The EA will not place the locked stop within
80% of the trigger, because that puts the stop on top of price and the trade
dies on the first wiggle. With the shipped 300 / 300 the guard caps the lock
at HALF the trigger (150 pips) and says so once in the Experts log. If you
want the lock honoured exactly as typed, use roughly 20-30% of the trigger -
about 60-90 pips against a 300 trigger.

Alerts:
  - Every colour change is alerted (ColourFlipAlert) - "BUY started - slope
    turned GREEN" / "SELL started - slope turned RED". These are never
    throttled; SignalAlertMaxPerHour (30) is only a backstop.
  - Risk alerts (drawdown, daily target, prop-firm breach) are always sent.
  - Trade-opened alerts are sent unless AlertOnTradeOpen is off.
  - Telegram: set TelegramAlert = true, TelegramToken, TelegramChatID, and
    allow https://api.telegram.org in the WebRequest list.

Dashboard (top-left of the chart):
  Title / version / price / status - SIGNAL (colour side + momentum bar) -
  Pause / Close all / Hide Panel - MANUAL Buy market / Sell market -
  PERFORMANCE (open positions, today trades, win rate, day P&L, last
  signal with the price it fired at) - MARKET (session, news, licence).
  The panel sizes itself to your display scaling and chart window
  (DashboardScale = 0); set a % to force a size.

Sessions: Tokyo, London and New York by default; no NEW trades in the last
3 hours of New York (NYLateCutoffHours, 19:00-22:00 server - open trades
keep running); everything flattened at 23:50 server time. News: pauses 1 hour either side of HIGH-impact USD
releases from the MT5 calendar.

Deposits and withdrawals do NOT count as profit or loss. The EA detects the
transfer and shifts its daily-loss, drawdown and profit-target baselines by
the same amount, so moving cash in or out will not close your open trades or
lock the day.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
