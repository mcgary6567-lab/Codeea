GOLD SCALPERS EA ADVANCED  -  Download package
==============================================
Version 4.11

Included:
  - Gold Scalpers EA Advanced.ex5                       (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers EA Advanced - Quick User Guide.pdf    (setup, how it trades, every setting)

WHAT IS NEW IN 4.11
  - Deposits and withdrawals no longer affect anything the EA measures. Day
    P&L and drawdown are now worked out from the deal history with transfers
    excluded, instead of being shifted by hand when the balance moved. Before
    this, re-attaching the EA after a deposit could count the same deposit
    again and pause trading on a drawdown that had not happened.
  - The start-up trade only fires on a FRESH colour. StartupMaxAgeBars (3) is
    how many bars ago the colour may have turned; anything older is alerted
    but not traded. Attaching the EA no longer opens a trade in the middle of
    an old move.
  - New optional chop filter MinPrevColourBars: skip a turn when the colour
    that just ended lasted fewer than N bars - that is what a flat, choppy
    range looks like. It ships off (0); set it to 2-4 if your own chart
    shows those green-red-green clusters and you would rather sit them out.
  - Everything else, including every default that the eight-month test was run
    on, is unchanged from 4.10.

WHAT WAS NEW IN 4.10
  - The colour-turn stop is capped at MaxStopPips (600). This was the single
    biggest improvement found in eight months of real-tick testing: it cut the
    average loss from 9.96 to 5.83 dollars.
  - Momentum gate set to 3 (was 10). With the stop capped, filtering less
    tested better - more trades and more profit for a little more drawdown.
  - Trailing TP from +300 pips, 150 behind price; the fixed target is removed
    so a winner can run.
  - Chart arrows now mark only the turns the EA actually traded, and they
    survive a setting change, a timeframe switch or a reload. The last 200
    bars of turns are redrawn when the EA starts.
  - Break-even lock default is 150 (it was 300, which the safety guard halved
    anyway and warned about on every attach).
  - Internal: position management reduced to a single pass per tick. Verified
    over eight months of real ticks to trade identically to the tested build.

What it is:
  A pure XAUUSD (gold) M5 scalper with ONE entry rule. The Slope Direction
  Line is drawn on your chart: GREEN while it is rising, RED while it is
  falling. When the line turns green the EA opens a BUY; when it turns red it
  opens a SELL. The stop sits beyond the candles where the colour changed,
  the target is a fixed 1200 pips ($12.00 on gold), and a break-even move
  protects the trade once it is in profit.

  Everything around that rule is the same engine as Gold Scalpers Pro: daily
  profit target, drawdown lock, prop-firm mode, sessions, news filter,
  loss-streak cooldown, pop-up / push / Telegram alerts, on-chart dashboard,
  manual buttons, pre-flight check and the goldscalpers.com licence.

  It can run on the same account as Gold Scalpers Pro (different magic
  number, separate day-state, separate panel). Use separate charts.

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy
     "Gold Scalpers EA Advanced.ex5" there. The indicator is bundled inside
     the EA - nothing else to install.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M5 chart, drag the EA on, tick "Allow Algo Trading".
     The default settings are already the tuned gold configuration - just
     click OK.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows
     you which server the EA talks to. You do not need to change it.
     The check is STRICT: if the URL is not allowed, the EA stays blocked.
     DEMO accounts need activation too - submit the demo login number the
     same way. Nothing runs unlicensed. The EA re-reads the licence list
     every 30 seconds, so activation takes effect within a minute - no
     restart needed.
  5. Activate your licence: submit your MT5 account number on your download
     page (https://goldscalpers.com/thank-you-advancedea) - it is authorized
     automatically within ~2 minutes. Or email it to support@goldscalpers.com.
  6. Read the pre-flight list in the Experts tab once after every attach.
     It tells you PASS / WARN / FAIL for each thing the EA depends on.

How it trades (short version):
  - Signal: on every CLOSED M5 candle the EA compares the line colour of the
    candle that just closed with the one before it. red -> green = BUY,
    green -> red = SELL. Nothing is read from the candle still forming.
  - Stop: beyond the extreme of ColourSLCandles (3) candles at the colour
    turn, plus ColourSLBufferPips (20). Never sent unprotected.
  - MaxStopPips (600): a CAP on how wide that stop may be. When the candles
    at the turn are far from the entry, the stop is pulled in to 600 pips
    instead. This is the most valuable setting in the EA - over eight months
    of real ticks it cut the average loss from 9.96 to 5.83 dollars and
    turned a loss into a profit. ClampWideStop = false skips those setups
    instead of capping them (far fewer trades, smallest drawdown tested).
  - Target: ColourTPPips = 1200 pips.
  - Break-even: at BreakEvenPips (300) in profit the stop moves to entry plus
    BreakEvenLockPips (150). See the note below.
  - Trailing TP (UseTrailingTP, on): from +300 pips the stop follows price
    150 pips behind in 20-pip steps and the fixed target is removed, so a
    winner runs as far as the move goes. TrailRemovesTP = false keeps the
    1200 target as a hard cap.
  - Momentum gate (MinTurnMomentumPct = 3): a colour turn is SKIPPED when
    the slope line is barely moving (below 3% of its own 20-bar average
    movement). This is the flat-chop filter and it is on by default - in
    two months of real-tick testing it removed about a third of the trades,
    the worst ones, and more than halved the drawdown. The alert still
    fires; the Experts log says 'flat slope - momentum N%'. Set 0 to take
    every turn.
  - Start-up: when attached, the EA alerts the colour already showing and,
    by default, trades it (StartupSlopeTrade = Follow). Set "No trade" for
    alert only.
  - One trade per signal (TradesPerSignal = 1, up to 10), MaxOpenPositions
    = 4, MaxTradesPerDay = 30.

NOTE ON THE BREAK-EVEN LOCK. The shipped pair is a 300-pip trigger with a
150-pip lock. The EA will not place the locked stop within 80% of the trigger,
because that would put the stop on top of price and the trade would die on the
first wiggle - so if you raise the lock towards the trigger it is capped and
the Experts log says so once.

Alerts:
  - Every colour change is alerted (ColourFlipAlert) - "BUY started - slope
    turned GREEN" / "SELL started - slope turned RED". These are never
    throttled; SignalAlertMaxPerHour (30) is only a backstop.
  - Risk alerts (drawdown, daily target, prop-firm breach) are always sent.
  - Trade-opened alerts are sent unless AlertOnTradeOpen is off.
  - Telegram: set TelegramAlert = true, TelegramToken, TelegramChatID, and
    allow https://api.telegram.org in the WebRequest list.

TRADING IT BY HAND (the strategy is simple enough to trade yourself):
  1. Attach the EA with EnableAutoTrading = false. It draws the line, the
     panel and the arrows and alerts every colour turn, but opens nothing.
  2. Wait for an M5 candle to CLOSE in the new colour. red -> green = BUY,
     green -> red = SELL. Never act on the candle still forming.
  3. Check the panel's SIGNAL row. If it says "momentum fading" (under about
     10%), skip the turn - that is the filter the EA uses.
  4. Click "Buy market" or "Sell market" on the panel. The EA places the
     trade with its own stop, target, break-even and trailing stop, so you
     choose the entry and it handles the management.
  5. Placing it yourself instead: stop just beyond the extreme of the 3
     candles at the turn, never more than $6.00 away; move the stop to entry
     at $3.00 profit, then trail $1.50 behind price.

  Best window in testing: 13:00-16:00 server time (London/New York overlap),
  84% of turns won over eight months. The 07:00-13:00 London morning was the
  weakest and lost money - consider sitting it out.

  NOTE: a high win rate is not the same as making money. In testing the
  settings with the HIGHEST win rates lost the most, because their losses
  were three times the size of their wins. Keep every loss small.

Full walkthrough with tables: see the Quick User Guide PDF, last page.

Chart arrows: BUY / SELL arrows mark the turns the EA traded (ArrowsTakenOnly),
  they survive setting changes, timeframe switches and reloads - only taking the
  EA off the chart clears them - and the last 200 bars of turns are redrawn when
  it starts (ArrowsKeepBars).

Dashboard (top-left of the chart):
  Title / version / price / status - SIGNAL (colour side + momentum bar) -
  Pause / Close all / Hide Panel - MANUAL Buy market / Sell market -
  PERFORMANCE (open positions, today trades, win rate, day P&L, last
  signal with the price it fired at) - MARKET (session, news, licence).
  The panel sizes itself to your display scaling and chart window
  (DashboardScale = 0); set a % to force a size.

Sessions: Tokyo, London and New York by default; no NEW trades in the last
3 hours of New York (NYLateCutoffHours, 19:00-22:00 server - open trades
keep running); everything flattened at 23:50 server time. News: pauses 1 hour either side of HIGH-impact USD
releases from the MT5 calendar.

Deposits and withdrawals do NOT count as profit or loss. The EA detects the
transfer and shifts its daily-loss, drawdown and profit-target baselines by
the same amount, so moving cash in or out will not close your open trades or
lock the day.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
