GOLD SCALPERS PRO  -  Download package
=====================================
Version 4.45  (build 2026-09-15)

IN THIS BUILD
  - Slope Direction Line period is now 10, not 12. Periods 8 to 16 were each
    run over eight months of real XAUUSD ticks; 10 gave both the best net
    result and the lowest drawdown of the set. The line turns a little sooner,
    so entries come earlier in a move.
  - New optional input MinTurnMomentumPct (default 0 = off). It scores how hard
    the slope line is moving when it turns, 0-100, against its own recent
    movement, and skips turns below the number you set. A flat turn is the line
    wobbling around a level rather than a new leg starting. Try 10 if you want
    fewer, cleaner entries in a ranging market.
  - The dashboard panel has been restyled and now fits any screen. It follows
    your Windows display scaling and, if the chart is too small to hold the
    full panel, shrinks it (down to 55%) instead of running off the edge.
    Resizing the window or moving the chart to another monitor re-fits it
    immediately. DashboardScale overrides the whole thing with a percentage of
    your own.

WHAT IS NEW IN 4.45
  - No new entries in the last 3 hours of New York (NYLateCutoffHours) or the
    first 2 hours of Tokyo (TokyoOpenSkipHours). Those are the thinnest hours
    of the session and the ones a stop is most often run in. Over eight months
    of real XAUUSD ticks these two filters alone turned the tested result from
    a small loss into a profit, with fewer trades and a lower drawdown.
  - When a colour turn does NOT become a trade, the Experts journal now says
    which gate stopped it - the 50-EMA side test, the chop filter, the MACD
    zero line, the confirmation candle, the daily cap or the news pause. One
    line per bar. "Ready to trade" and "COLOUR FLIP" are alerts, not entries:
    an entry needs a fresh trigger that clears every gate, and it is evaluated
    one bar after the flip because the next candle has to confirm it.
  - Every signal now prints a BUY or SELL label next to its arrow on the chart,
    on the bar that triggered it. Start-up trades and the manual Buy/Sell
    buttons are labelled the same way. Two new inputs control it:
      - ArrowsTakenOnly (true)  mark only trades that actually opened; set it
                                false to mark every signal, filtered ones too
      - ArrowsKeepBars  (200)   redraw the colour turns of the last N closed
                                bars on start-up, so a fresh attach is not an
                                empty chart (0 = only new ones)
    ShowSignalArrows turns all of it off.
  - Telegram alerts are queued and sent by the EA's timer instead of inline, so
    a slow send can no longer delay an entry or a stop move, and the licence
    check backs off while the server cannot be reached. Nothing the EA does on
    a tick waits on the network.
  - Defaults: one entry per signal (UseScaleIn = false), max 14 new trades per
    day, max drawdown 12%. Tested over eight months of real XAUUSD ticks.
  - Stop-width cap (MaxStopPips, with ClampWideStop) is available but ships
    OFF. It does cut the average loss - a 600-pip cap took it from 15.12 to
    6.11 over eight months of real ticks - but it also dropped the win rate
    from 72% to 49%, because this EA's stop already sits at real swing
    structure and tightening it turns winners into losers. Set it only if you
    want a smaller drawdown and accept fewer winners.
  - Stop loss and take profit are now measured against the prices the SERVER
    checks - a buy against the bid, a sell against the ask - plus the minimum
    stop distance of your broker. Before this, a tight setup on a wide spread
    could be refused with "invalid stops" and the trade never opened.
  - Free margin is checked before an order is sent, so an under-funded account
    gets one clear line in the Experts log instead of a run of broker
    rejections. It only blocks a trade when the broker reports a requirement
    larger than your free margin.
  - Deposits and withdrawals no longer affect anything the EA measures. Day
    P&L and drawdown are worked out from the deal history with transfers
    excluded, so moving money in or out is not read as a trading result. The
    previous build could count the same deposit again on every re-attach and
    pause trading on a drawdown that had not happened.
  - The start-up trade only fires on a colour that turned within the last
    3 bars (StartupMaxAgeBars). Attaching the EA no longer opens a trade on a
    colour that turned an hour ago.
  - Licence: demo and real accounts both need activation now, and an account
    that has never verified cannot trade. A previously verified account keeps
    running for 3 days if the licence server cannot be reached. The Strategy
    Tester always runs, so you can still backtest freely.

Included:
  - Gold Scalpers Pro.ex5                        (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers Pro - Quick User Guide.pdf     (setup + all settings)
  - Gold Scalpers Pro - Manual Trading Guide.pdf (trade the strategy yourself, step by step)

Build 2026-09-11 - licence check fixed:
  The EA could not read its own licence-server address (a decoding bug),
  so the check silently passed every real account. It now reaches
  https://goldscalpers.com/licenses.txt as intended. If you never activated,
  your account will now show "License not active": submit your MT5 login on
  https://goldscalpers.com/thank-you-pro (2 minutes) or email support.

What is new in 4.40:
  DEFAULT SETTINGS CHANGED. The EA ships more active than before. If you prefer
  the previous, more selective behaviour, the old values are noted in brackets.

    EntryMode            = Either fires      (was: Slope x EMA cross only)
        BOTH triggers are now live. A slope colour flip and a slope/50-EMA cross
        can each open a trade, whichever comes first, and that trade uses the
        stop and target belonging to the trigger that fired it - the colour-turn
        stop for a flip, the swing stop for a cross. Only one trade runs at a
        time; the two triggers share the single position slot.
    StartupSlopeTrade    = Follow the colour (was: No trade)
        Attaching the EA now OPENS a trade on the colour already showing - green
        a BUY, magenta a SELL. Set it back to "No trade" for alert only.
    SessTokyo            = true              (was: false)
        The Asian session is enabled. It is quieter than London, so the chop
        filter and the confirmation bar carry more of the load there.
    TakeProfitPips       = 1500              (was: 500)      $15.00 on gold
    BreakEvenPips        = 700               (was: 300)      $7.00 on gold
    BreakEvenLockPips    = 700               (was: 200)
    MaxOpenPositions     = 4                 (was: 3)

  NOTE ON THE BREAK-EVEN LOCK. The EA will not place the locked stop within 80%
  of the trigger, because that puts the stop on top of price and the trade dies
  on the first wiggle. With 700 / 700 the guard caps the lock at HALF the
  trigger and says so once in the Experts log. If you want the lock honoured
  exactly as typed, use roughly 20-30% of the trigger - about 150-200 against a
  700 trigger.

What was new in 4.30:
  1. STRATEGY PRESETS (the very first input, above everything else).
     The EA can trade two different ways; a preset sets that up in one click.
       - Custom (default)     every input below is used exactly as you set it.
                              Nothing is overridden. Existing setups are unchanged.
       - Colour scalping      trades the GREEN / MAGENTA turns of the Slope line.
                              No MACD wait, no EMA-side rule, no confirmation
                              candle. Stop from the colour turn, target 500.
       - EMA + MACD swing     trades the Slope line crossing the 50 EMA, confirmed
                              by MACD, price on the correct side of the EMA, one
                              confirmation candle. Swing stop, group-3 target.
     A preset NEVER touches risk: lot size, daily limits, the drawdown cap,
     sessions, news and Prop-Firm Mode all stay yours, so either strategy can run
     under prop-firm rules.
     IMPORTANT: a preset wins over the inputs it owns. MetaTrader cannot grey an
     input out, so the pre-flight block in the Experts log lists the active preset
     and every value it changed, and the dashboard header shows the preset name.
     If the header shows a preset, that preset is in charge. Pick Custom to make
     your own inputs win.

  2. COLOUR-TURN ALERTS, every time (not just at start-up).
     The EA now alerts you EVERY time the Slope line changes colour, for as long
     as the chart is open, and the dashboard's "Last signal" row reads
     "Buy Started" or "Sell Started". It reads the last CLOSED candle, never the
     one still forming, because a live candle's slope can flip and flip back.
       - ColourFlipAlert        (true)  alert on every colour change
       - SignalAlertMaxPerHour  (30)    backstop only; 0 = unlimited
     Colour alerts are NEVER delayed by the anti-spam throttle. Alert priority is
     now: risk alerts always, then colour turns, then trade-opened, and only the
     "ready to trade" alert is throttled.

  3. SEPARATE STOP AND TARGET FOR COLOUR ENTRIES (inputs group 0b).
     A colour entry and an EMA-cross entry want different protection, so they get
     it. Colour entries take the stop from the candles AT THE COLOUR TURN plus a
     buffer; EMA-cross entries keep the swing stop. Whichever logic fired the
     trade decides, automatically.
       - ColourTradeOwnRisk (true) colour entries use the stop/target below
       - ColourSLCandles    (3)    candles at the turn that define the stop
       - ColourSLBufferPips (20)   extra room beyond that extreme
       - ColourTPPips       (500)  take profit for colour entries only

  4. FIXES AND TUNING.
     - A new trading day now clears yesterday's max-drawdown pause. Before this,
       an EA left running across midnight could stay locked out of trading even
       though the drawdown baseline had reset.
     - When a trade is skipped, the Experts log now names the exact reason
       (drawdown pause, session, news, spread, daily cap, ...) instead of a vague
       "a filter blocked it".
     - The "ready to trade" alert re-arms on a direction change again, so an
       opposite-side signal is no longer missed.
     - Less wasted work per tick: readiness is computed once per candle instead of
       three times a second, the chart-object sweep is skipped when no pending
       orders exist, and the day's peak equity is persisted at most every 10s.

What was new in 4.20:
  1. START-UP SLOPE SIGNAL (inputs group 0, at the top of the list).
     When you attach the EA it reads the colour the Slope Direction Line is
     drawing right now and alerts you once: GREEN = the line is rising (buy
     side), MAGENTA = falling (sell side). It uses the same rising/falling
     test as the indicator itself, so the alert always matches the line on
     your chart. From the next bar the normal crossover engine takes over.
       - StartupSlopeAlert   (true)            alert the colour on start
       - StartupSlopeTrade   (No trade)        also open a trade on it:
                                               Follow  = green BUY, magenta SELL
                                               Reverse = the opposite
       - StartupSlopeBar     (Last closed bar) which bar the colour is read from
       - StartupTradeFilters (true)            the start-up trade must pass the
                                               normal session / news / spread /
                                               limit filters
     It fires once per attach. Reloading the EA or changing a setting restarts
     it, so the alert comes again - that is the same event, not a new signal.

  2. ANTI-SPAM ALERT THROTTLE (inputs group 8).
     Alerts are now graded. Risk alerts (max drawdown, daily profit target,
     prop-firm breach) are ALWAYS sent. Trade-opened alerts are
     sent unless you switch them off. Informational alerts ("ready to trade",
     start-up slope colour) pass a minimum gap, an hourly ceiling and duplicate
     suppression. A "ready" reading that flipped between buy and sell used to
     re-arm the alert on every bar in a choppy market - that is fixed.
       - AlertOnTradeOpen (true)  alert when the EA opens a trade
       - AlertMinGapSec   (300)   min seconds between info alerts (0 = off)
       - AlertMaxPerHour  (12)    max info alerts per hour (0 = unlimited)
       - AlertRepeatSame  (false) allow the same info alert inside the gap
     Every held-back alert is still written to the Experts journal, so nothing
     disappears silently.

  3. DASHBOARD LAYOUT.
     The manual Buy market / Sell market buttons moved to the TOP of the panel,
     directly under Pause / Close all / Hide Panel, so everything you click is
     together. Session and news (MARKET) moved to the bottom. The new order is
     SIGNAL, control buttons, MANUAL, PERFORMANCE, MARKET. The panel is drawn
     when the EA is attached - remove it from the chart and drag it back on to
     see the new layout.

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers Pro.ex5" there.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M5 chart, drag the EA on, tick "Allow Algo Trading".
     The default settings are already the tuned gold configuration - just click OK.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you-pro) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) scalper on the M5 timeframe. Two triggers can
open a trade and both are live by default (EntryMode = Either): the Slope
Direction Line crossing the 50 EMA, and the Slope line changing direction. Each
one is confirmed by ZeroLag MACD, a chop filter and a confirmation candle. The
stop loss sits at the most recent swing low/high beyond the 50 EMA (real market
structure), with a $15 take-profit and a break-even that locks a winner in
profit.

Out of the box a signal opens ONE market order - no pyramiding. Eight months of
XAUUSD tick testing came out ahead that way, so that is how it ships. These
settings change it:
  - UseScaleIn (default OFF) - Momentum Pyramiding. Turn it on and the EA queues
    add-on stop orders AHEAD of the entry, so they fill only while the move runs
    your way, never by averaging down. Each add-on carries the same stop as the
    first order.
  - AdditionalTrades (default 1, max 30) - how many add-ons are queued, spaced
    PipsInterval apart.
  - TradesPerSignal (default 1, max 10) - open more than one position per
    signal, each with its own stop and target.
  - MaxOpenPositions caps the total either way (0 = no cap).

Sessions: Tokyo, London and New York by default, minus the last 3 hours of New
York (NYLateCutoffHours) and the first 2 hours of Tokyo (TokyoOpenSkipHours).
Optional Prop-Firm Mode enforces %-based daily-loss and max-drawdown limits.

Deposits and withdrawals do NOT count as profit or loss. The day's P&L is added
up from your closed deals with balance operations left out, so a transfer is
invisible to it - there is no baseline to shift and nothing to re-apply when the
EA reloads. Moving cash in or out will not close your open trades or lock the
day. Position sizing still follows the real balance.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
