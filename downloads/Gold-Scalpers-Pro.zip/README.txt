GOLD SCALPERS PRO  -  Download package
=====================================
Version 4.20

Included:
  - Gold Scalpers Pro.ex5                        (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers Pro - Quick User Guide.pdf     (setup + all settings)
  - Gold Scalpers Pro - Manual Trading Guide.pdf (trade the strategy yourself, step by step)

What is new in 4.20:
  1. START-UP SLOPE SIGNAL (inputs group 0, at the top of the list).
     When you attach the EA it reads the colour the Slope Direction Line is
     drawing right now and alerts you once: GREEN = the line is rising (buy
     side), MAGENTA = falling (sell side). It uses the same rising/falling
     test as the indicator itself, so the alert always matches the line on
     your chart. From the next bar the normal crossover engine takes over.
       - StartupSlopeAlert   (true)            alert the colour on start
       - StartupSlopeTrade   (No trade)        also open a trade on it:
                                               Follow  = green BUY, magenta SELL
                                               Reverse = the opposite
       - StartupSlopeBar     (Last closed bar) which bar the colour is read from
       - StartupTradeFilters (true)            the start-up trade must pass the
                                               normal session / news / spread /
                                               limit filters
     It fires once per attach. Reloading the EA or changing a setting restarts
     it, so the alert comes again - that is the same event, not a new signal.

  2. ANTI-SPAM ALERT THROTTLE (inputs group 8).
     Alerts are now graded. Risk alerts (max drawdown, daily loss limit, daily
     profit target, prop-firm breach) are ALWAYS sent. Trade-opened alerts are
     sent unless you switch them off. Informational alerts ("ready to trade",
     start-up slope colour) pass a minimum gap, an hourly ceiling and duplicate
     suppression. A "ready" reading that flipped between buy and sell used to
     re-arm the alert on every bar in a choppy market - that is fixed.
       - AlertOnTradeOpen (true)  alert when the EA opens a trade
       - AlertMinGapSec   (300)   min seconds between info alerts (0 = off)
       - AlertMaxPerHour  (12)    max info alerts per hour (0 = unlimited)
       - AlertRepeatSame  (false) allow the same info alert inside the gap
     Every held-back alert is still written to the Experts journal, so nothing
     disappears silently.

  3. DASHBOARD LAYOUT.
     The manual Buy market / Sell market buttons moved to the TOP of the panel,
     directly under Pause / Close all / Hide Panel, so everything you click is
     together. Session and news (MARKET) moved to the bottom. The new order is
     SIGNAL, control buttons, MANUAL, PERFORMANCE, MARKET. The panel is drawn
     when the EA is attached - remove it from the chart and drag it back on to
     see the new layout.

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers Pro.ex5" there.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M5 chart, drag the EA on, tick "Allow Algo Trading".
     The default settings are already the tuned gold configuration - just click OK.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) scalper on the M5 timeframe - the Slope Direction
Line crossing the 50 EMA (confirmed by ZeroLag MACD). The stop loss sits at the
most recent swing low/high beyond the 50 EMA (real market structure), with
a $5 take-profit and a break-even that locks a winner in profit.

Out of the box the EA takes ONE trade per signal. Two settings change that:
  - UseScaleIn (default OFF) - Momentum Pyramiding. Turn it on and the EA adds
    orders into a WINNING trade as it runs, never averaging down, with a
    step-stop that tightens as each add-on fills. The add-ons carry the same
    stop as the first order.
  - TradesPerSignal (default 1, max 10) - open more than one position per
    signal, each with its own stop and target.
  - MaxOpenPositions caps the total either way (0 = no cap).

Sessions: London and New York by default.
Optional Prop-Firm Mode enforces %-based daily-loss and max-drawdown limits.

Deposits and withdrawals do NOT count as profit or loss. The EA detects the
transfer and shifts its daily-loss, drawdown and profit-target baselines by the
same amount, so moving cash in or out will not close your open trades or lock
the day. Position sizing still follows the real balance.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
