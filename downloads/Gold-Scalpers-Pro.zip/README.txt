GOLD SCALPERS PRO  -  Download package
=====================================
Version 4.40

Included:
  - Gold Scalpers Pro.ex5                        (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers Pro - Quick User Guide.pdf     (setup + all settings)
  - Gold Scalpers Pro - Manual Trading Guide.pdf (trade the strategy yourself, step by step)

What is new in 4.40:
  DEFAULT SETTINGS CHANGED. The EA ships more active than before. If you prefer
  the previous, more selective behaviour, the old values are noted in brackets.

    EntryMode            = Either fires      (was: Slope x EMA cross only)
        BOTH triggers are now live. A slope colour flip and a slope/50-EMA cross
        can each open a trade, whichever comes first, and that trade uses the
        stop and target belonging to the trigger that fired it - the colour-turn
        stop for a flip, the swing stop for a cross. Only one trade runs at a
        time; the two triggers share the single position slot.
    StartupSlopeTrade    = Follow the colour (was: No trade)
        Attaching the EA now OPENS a trade on the colour already showing - green
        a BUY, magenta a SELL. Set it back to "No trade" for alert only.
    SessTokyo            = true              (was: false)
        The Asian session is enabled. It is quieter than London, so the chop
        filter and the confirmation bar carry more of the load there.
    TakeProfitPips       = 1500              (was: 500)      $15.00 on gold
    BreakEvenPips        = 700               (was: 300)      $7.00 on gold
    BreakEvenLockPips    = 700               (was: 200)
    MaxOpenPositions     = 4                 (was: 3)

  NOTE ON THE BREAK-EVEN LOCK. The EA will not place the locked stop within 80%
  of the trigger, because that puts the stop on top of price and the trade dies
  on the first wiggle. With 700 / 700 the guard caps the lock at HALF the
  trigger and says so once in the Experts log. If you want the lock honoured
  exactly as typed, use roughly 20-30% of the trigger - about 150-200 against a
  700 trigger.

What was new in 4.30:
  1. STRATEGY PRESETS (the very first input, above everything else).
     The EA can trade two different ways; a preset sets that up in one click.
       - Custom (default)     every input below is used exactly as you set it.
                              Nothing is overridden. Existing setups are unchanged.
       - Colour scalping      trades the GREEN / MAGENTA turns of the Slope line.
                              No MACD wait, no EMA-side rule, no confirmation
                              candle. Stop from the colour turn, target 500.
       - EMA + MACD swing     trades the Slope line crossing the 50 EMA, confirmed
                              by MACD, price on the correct side of the EMA, one
                              confirmation candle. Swing stop, group-3 target.
     A preset NEVER touches risk: lot size, daily limits, the drawdown cap,
     sessions, news and Prop-Firm Mode all stay yours, so either strategy can run
     under prop-firm rules.
     IMPORTANT: a preset wins over the inputs it owns. MetaTrader cannot grey an
     input out, so the pre-flight block in the Experts log lists the active preset
     and every value it changed, and the dashboard header shows the preset name.
     If the header shows a preset, that preset is in charge. Pick Custom to make
     your own inputs win.

  2. COLOUR-TURN ALERTS, every time (not just at start-up).
     The EA now alerts you EVERY time the Slope line changes colour, for as long
     as the chart is open, and the dashboard's "Last signal" row reads
     "Buy Started" or "Sell Started". It reads the last CLOSED candle, never the
     one still forming, because a live candle's slope can flip and flip back.
       - ColourFlipAlert        (true)  alert on every colour change
       - SignalAlertMaxPerHour  (30)    backstop only; 0 = unlimited
     Colour alerts are NEVER delayed by the anti-spam throttle. Alert priority is
     now: risk alerts always, then colour turns, then trade-opened, and only the
     "ready to trade" alert is throttled.

  3. SEPARATE STOP AND TARGET FOR COLOUR ENTRIES (inputs group 0b).
     A colour entry and an EMA-cross entry want different protection, so they get
     it. Colour entries take the stop from the candles AT THE COLOUR TURN plus a
     buffer; EMA-cross entries keep the swing stop. Whichever logic fired the
     trade decides, automatically.
       - ColourTradeOwnRisk (true) colour entries use the stop/target below
       - ColourSLCandles    (3)    candles at the turn that define the stop
       - ColourSLBufferPips (20)   extra room beyond that extreme
       - ColourTPPips       (500)  take profit for colour entries only

  4. FIXES AND TUNING.
     - A new trading day now clears yesterday's max-drawdown pause. Before this,
       an EA left running across midnight could stay locked out of trading even
       though the drawdown baseline had reset.
     - When a trade is skipped, the Experts log now names the exact reason
       (drawdown pause, session, news, spread, daily cap, ...) instead of a vague
       "a filter blocked it".
     - The "ready to trade" alert re-arms on a direction change again, so an
       opposite-side signal is no longer missed.
     - Less wasted work per tick: readiness is computed once per candle instead of
       three times a second, the chart-object sweep is skipped when no pending
       orders exist, and the day's peak equity is persisted at most every 10s.

What was new in 4.20:
  1. START-UP SLOPE SIGNAL (inputs group 0, at the top of the list).
     When you attach the EA it reads the colour the Slope Direction Line is
     drawing right now and alerts you once: GREEN = the line is rising (buy
     side), MAGENTA = falling (sell side). It uses the same rising/falling
     test as the indicator itself, so the alert always matches the line on
     your chart. From the next bar the normal crossover engine takes over.
       - StartupSlopeAlert   (true)            alert the colour on start
       - StartupSlopeTrade   (No trade)        also open a trade on it:
                                               Follow  = green BUY, magenta SELL
                                               Reverse = the opposite
       - StartupSlopeBar     (Last closed bar) which bar the colour is read from
       - StartupTradeFilters (true)            the start-up trade must pass the
                                               normal session / news / spread /
                                               limit filters
     It fires once per attach. Reloading the EA or changing a setting restarts
     it, so the alert comes again - that is the same event, not a new signal.

  2. ANTI-SPAM ALERT THROTTLE (inputs group 8).
     Alerts are now graded. Risk alerts (max drawdown, daily loss limit, daily
     profit target, prop-firm breach) are ALWAYS sent. Trade-opened alerts are
     sent unless you switch them off. Informational alerts ("ready to trade",
     start-up slope colour) pass a minimum gap, an hourly ceiling and duplicate
     suppression. A "ready" reading that flipped between buy and sell used to
     re-arm the alert on every bar in a choppy market - that is fixed.
       - AlertOnTradeOpen (true)  alert when the EA opens a trade
       - AlertMinGapSec   (300)   min seconds between info alerts (0 = off)
       - AlertMaxPerHour  (12)    max info alerts per hour (0 = unlimited)
       - AlertRepeatSame  (false) allow the same info alert inside the gap
     Every held-back alert is still written to the Experts journal, so nothing
     disappears silently.

  3. DASHBOARD LAYOUT.
     The manual Buy market / Sell market buttons moved to the TOP of the panel,
     directly under Pause / Close all / Hide Panel, so everything you click is
     together. Session and news (MARKET) moved to the bottom. The new order is
     SIGNAL, control buttons, MANUAL, PERFORMANCE, MARKET. The panel is drawn
     when the EA is attached - remove it from the chart and drag it back on to
     see the new layout.

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers Pro.ex5" there.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M5 chart, drag the EA on, tick "Allow Algo Trading".
     The default settings are already the tuned gold configuration - just click OK.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) scalper on the M5 timeframe - the Slope Direction
Line crossing the 50 EMA (confirmed by ZeroLag MACD). The stop loss sits at the
most recent swing low/high beyond the 50 EMA (real market structure), with
a $5 take-profit and a break-even that locks a winner in profit.

Out of the box the EA takes ONE trade per signal. Two settings change that:
  - UseScaleIn (default OFF) - Momentum Pyramiding. Turn it on and the EA adds
    orders into a WINNING trade as it runs, never averaging down, with a
    step-stop that tightens as each add-on fills. The add-ons carry the same
    stop as the first order.
  - TradesPerSignal (default 1, max 10) - open more than one position per
    signal, each with its own stop and target.
  - MaxOpenPositions caps the total either way (0 = no cap).

Sessions: London and New York by default.
Optional Prop-Firm Mode enforces %-based daily-loss and max-drawdown limits.

Deposits and withdrawals do NOT count as profit or loss. The EA detects the
transfer and shifts its daily-loss, drawdown and profit-target baselines by the
same amount, so moving cash in or out will not close your open trades or lock
the day. Position sizing still follows the real balance.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
