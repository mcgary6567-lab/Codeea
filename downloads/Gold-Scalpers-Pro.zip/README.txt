GOLD SCALPERS PRO  -  Download package
=====================================
Version 4.50  (build 2026-10-22)

IN THIS BUILD  (4.50, 2026-10-22)
  - NEWS TRADES GO IMMEDIATELY AND ON EVERY STORY. The reader checks
    ForexFactory every 2 minutes and the EA reads the result every 30 seconds,
    so a new story is acted on about 1-3 minutes after it appears. Every story
    that names a side with confidence 3 or more opens its own trade (one per
    story, no daily limit - HotStoryMaxPerDay 0), and the trade runs to its
    stop or target (no time stop - HotStoryTimeStopHours 0). A news trade no
    longer waits on the daily profit target, the daily trade cap, the
    calendar news pause or the sessions (HotStoryRespectSession off). Still
    required: the 50 EMA on that symbol agrees, the stop fits the 600-pip cap,
    spread and margin are fine, and no drawdown / loss / prop stop is active.
  - THE NEWS SIGNAL SHOWS FOR 15 MINUTES (HotStoryShowMin, group 9). After
    that the panel and the news strip say "waiting for next story"; the last
    headline stays in the tooltip.
  - DAY P&L FIX. Attaching or reloading the EA mid-day while trades were open
    booked those trades' floating loss as "carried in from yesterday", so the
    panel could show a losing day as a profit (and the drawdown guard read the
    same wrong number). Only positions opened before today now count as
    carried in, and a wrong stored value is corrected on the next attach.
    The Open positions row now says e.g. "0 (5 on account)" when you have
    manual trades the EA did not open.
  - Backtest of the shipped defaults, latest month of real ticks (2026-09-14 to 10-14, 0.01 lot): +77.81, PF 1.33, 127 trades, 83.5% won, 5.37% drawdown.
    News trades are not in that figure: the tester has no story feed.

IN 4.49  (2026-10-15)
  - THE SESSION SWITCHES ARE BACK IN THE INPUTS (group 6) and the fixed
    10:00-19:00 window is gone. Defaults: Sydney, Tokyo, London and New York
    all on; no new entries in the FIRST 2 HOURS OF SYDNEY (SydneyOpenSkipHours,
    21:00-23:00 server) or the LAST 2 HOURS OF NEW YORK (NYLateCutoffHours,
    20:00-22:00). Switch any session off, or set a cut-off to 0, to change it.
    The "Low drawdown (NY only)" preset still trades 13:00-19:00 only.
  - BreakEvenLockPips now ships at 300, equal to the 300-pip trigger: the stop
    goes to price at +300, so a trade closes there with about that profit.
    Set it to 150 if you prefer winners to run on past +300.
  - Backtest: the eight-month run of this exact setup was not completed before release; the closest measured setup, the old three sessions, made +99.33 over eight months with a losing January-May (see the session table in the guide).
    For comparison on the same data: the 10:00-19:00 window made +251.85
    (15.6% drawdown) and the Low drawdown preset +265.33 (10.3%). Pick the
    preset if the floor matters more to you than the hours traded.

IN 4.48  (2026-10-15)
  - ONE SIGNAL ALERT: THE SLOPE / 50 EMA CROSS. New input CrossAlert (group 0,
    on): when the Slope line crosses the 50 EMA on a closed candle you get one
    alert - "BUY - slope crossed ABOVE the 50 EMA" or "SELL - slope crossed
    BELOW the 50 EMA" - with price and EMA value, and the panel's Last signal
    row shows it. The slope colour alerts (green / magenta on every change, and
    the colour on attach) and the "ready to trade" readiness alert are now OFF
    by default, so the cross is the only market-signal alert. Each is still an
    input (ColourFlipAlert, StartupSlopeAlert, SetupFormingAlert) if you want
    it back. Trade, risk and news alerts are unchanged, and so is trading: the
    colour-turn entries and the start-up trade work exactly as before.

IN 4.47  (2026-10-12)
  - THE SIGNAL METER CAN NO LONGER READ 100% WHILE A GATE FAILS. The EMA part
    of the meter used to fade gradually on the wrong side of the 50 EMA, so
    with price just above the EMA and the slope pointing down the panel could
    read "SELL 100%" while the trend rule every entry needs was failing. Now
    the wrong side scores zero, the right side only scores in full once price
    is clear of the chop gap (MinEmaGapBoxes bodies from the EMA), and the
    whole reading is capped at 60% while any gate fails. A "ready to trade"
    alert at 100% therefore means a trade can actually open on the next
    qualifying candle. New status text: "price hugging the EMA (chop filter)".

  - MANUAL BUY / SELL BUTTONS NO LONGER MARK THE CHART. The BUY / SELL label on
    a candle now means one thing only: the EA's own signal opened a trade.

  - DEPOSITS AND WITHDRAWALS CANNOT SHOW AS DRAWDOWN, EVEN FOR A MOMENT. The
    terminal moves the balance a moment before it writes the transfer into
    the deal history, and in that gap a withdrawal looked like a loss, so the
    drawdown figure and warning could fire. A balance move now has to be
    explained by the history (a closed trade or a transfer) before any
    percentage gate reads equity; until it is, the EA rescans every tick and
    the drawdown, daily-loss and prop-firm checks stand down (30 s at most).
    The Experts log prints "balance moved ... risk gates stand down" and then
    "explained". On top of that the drawdown itself is now measured on TRADING
    money only - realised plus floating P&L from the day's best point - so
    withdrawing the day's profit, or the whole balance, cannot read as a drop
    (it did on 2026-10-12: the guard read the 1.20 left behind as a 100%
    drawdown and paused the EA). The percentage is of the capital at the day's
    best point or the real account now, whichever is larger.

  - A PROPER CLOSE ALERT. MetaTrader's own notification names the closing
    deal, and closing a BUY is a sell deal, so it reads "sell ... closed" for a
    buy. The EA now sends its own: "BUY closed - XAUUSD 0.01 lot @ price,
    +3.02 USD, by take profit / stop loss / the EA / you (manual close)". It
    follows the AlertOnTradeOpen switch, like the open alert.

  - THE AI NEWS READ IS NOW A DEEP READ (server side, no reinstall needed).
    The reader used to send the model one summary sentence and tell it that
    "no clear side" is usually right. It now sends the whole article (the
    ForexFactory excerpt plus the source piece behind the "full story" link,
    fetched automatically) and works through a desk method: what is actually
    new versus already priced, the transmission channel (rates and yields,
    dollar demand, risk appetite, safe-haven flows, inflation, geopolitics,
    energy), which of the eight instruments it moves and which way, then a
    confidence of 1 to 5, with a written analysis you can read in the server
    file. "No clear side" is now reserved for stories with no channel at all.

  - REMOVED: the support / resistance lines and the TradingView link that
    shipped on 2026-10-11 are withdrawn - they cluttered the chart and the
    levels were display only. Group 9 is back to the panel and arrow options.

  - EARLY DRAWDOWN WARNING. New input DrawdownWarnPct (group 2, default 10).
    When the day's drawdown first reaches it you get one risk-level alert on
    every channel you have on, with how far the MaxDrawdownPct stop still is
    and how many trades are open, and the panel status reads "near drawdown
    stop". It re-arms once half of that drawdown is recovered. 0 = off.

  - THE NEWS ROW IS FASTER. The reader checks ForexFactory every 5 minutes
    (was 20) and the EA reads the result every 2 (was 5), so a new top story
    reaches the panel within about 4 minutes, 7 at worst.

  - (4.46-4.48 only - reversed in 4.49, see the top) THE TRADING WINDOW WAS
    FIXED AT 10:00-19:00 SERVER TIME and the session settings were not inputs: no toggles, no cut-offs, no custom window.
    London morning from 10:00, the London / New York overlap, New York until
    19:00 - nine hours a day. The only way to change it is the "Low drawdown
    (NY only)" preset, 13:00-19:00. Round-the-clock trading was measured on
    this build before the decision: -176.01 over eight months, 32.7%
    drawdown, against +251.81 for the window - the 19:00-02:00 hours lose.

  - THE END-OF-DAY FLATTEN IS GONE (NoOvernight / FlatTime). It shipped off
    since 2026-09-27 and nothing else used it; a trade is now closed only by
    its stop, its target, the drawdown guard or you.

  - BreakEvenLockPips is honoured exactly as typed; the old half-trigger cap
    and its warning are removed. The default is 150 against the 300 trigger -
    the same value the cap produced, so behaviour is unchanged. Typing 300
    (lock = trigger) now really closes the trade at +300: measured +6.80
    against +47.71 over the last month, because it cuts the runners.

  - (2026-10-03) THE WINDOW RESEARCH that led to the 10:00-19:00 default:

    WHY. Eight months of real XAUUSD ticks (2026-01-12 to 09-14) were taken
    apart trade by trade. The afternoon (12:00-19:00 server) earned the entire
    profit at an 88% win rate; the London morning (07:00-12:00) lost 220 and
    the Tokyo hours were flat. The three-session setup had a LOSING half-year
    (January-May, -181.94, 25.6% drawdown) that the summer then paid back.
    Every number below is a tester result, not a projection:

        window      three sessions (old)   10-19h window (NEW DEFAULT)   NY only (preset)
        1 month     +63.13  PF 1.41  73      +21.64  PF 1.35   31          +24.95  PF 1.80   21
        2 months    +90.75  PF 1.26  169     +59.10  PF 1.33   89          +46.93  PF 1.46   53
        6 months   +312.66  PF 1.28  535    +328.81  PF 1.67  288         +245.68  PF 2.08  166
        8 months    +99.33  PF 1.06  727    +251.81  PF 1.28  408         +265.33  PF 1.58  246
        Jan-May    -181.94  PF 0.84  387     -19.96  PF 0.97  221          +89.24  PF 1.30  137
        May-Sep    +281.27  PF 1.43  340    +271.77  PF 1.92  187         +176.09  PF 2.11  109
        max drawdown  25.6%                    15.6%                         10.3%

    Read it straight: the old setup earns more in a good stretch because it
    takes more trades; the window keeps about 97% of that and removes about
    90% of the bad-stretch loss. NY-only has the highest floor - never a
    losing half - and the lowest ceiling.

  - NEW STRATEGY PRESET: "Low drawdown (NY only)". Sets the window to
    13:00-19:00 and changes nothing else. For funded accounts with a daily
    loss limit, or anyone who would rather have the floor than the ceiling.

  - UPDATE NOTICE AND ONE-CLICK RELOAD. The EA checks goldscalpers.com every
    30 minutes for a newer build. When there is one you get a single alert
    and the version label at the top-right of the panel turns blue and reads
    "v4.50 -> 4.51", with what changed and the download link in its tooltip.
    Installing is then: download the zip, copy the new .ex5 into
    MQL5\Experts, and CLICK THE VERSION LABEL TWICE within five seconds. The
    EA reloads itself with the new file - your inputs and the day's state are
    kept, open positions are untouched. (The first click arms it and the label
    says "click again to reload", so a stray click never reloads anything.)
    Note that a reload re-runs the start-up checks exactly like a fresh
    attach, so it can open a start-up trade if the colour turned in the last
    few bars - pick a quiet moment. The EA cannot download or install the
    file itself: MetaTrader keeps every EA out of the Experts folder on
    purpose, and that is a protection you want.

  - THE AI NEWS ROW NOW TRADES, AND IT IS ON BY DEFAULT (HotStoryTrade = true,
    settings group 10). When the hot story names a side, the EA opens ONE
    market order on the symbol the story names - a gold chart can open GBPUSD.
    Target 1000 pips, stop beyond the last 2 closed candles plus 30 pips (cap
    600), (since 4.50: no time stop, no daily limit) only WITH the
    50 EMA on that symbol, model confidence 3 or more, story under an hour
    old. Those pip values are written for gold and are rescaled for any other
    symbol by its ATR, so they mean the same thing in volatility terms.

    READ THIS BEFORE YOU LEAVE IT ON: this entry CANNOT BE BACKTESTED. The
    Strategy Tester has no story feed, so NONE of the figures in this file,
    the guide or the website include a single hot-story trade. Every build
    this week was parity-tested and reproduced the tested figures to the cent
    - which proves the tested path is untouched, and also proves the tester
    never sees a story. If you want the EA to trade only what has been
    measured, set HotStoryTrade = false and the row goes back to display only.

  - A news strip at the top of the chart (group 11): the hot story and the
    model's read, then the next calendar events numbered to match their
    vertical lines, with time, countdown, currency, forecast and previous.
    Released events stay on it for three hours with the ACTUAL shown - green
    when the calendar reads it as good for the currency, red when bad.

  - News filter window is now 30 minutes each side of a high-impact release
    (NewsBeforeSec / NewsAfterSec 1800, were 3600). New: the Slope/EMA entries
    also pause for 30 minutes after a hot story that names a side
    (HotStoryPauseMin). The hot-story trade itself is not paused by its own
    story - it exists to act on it.

  - FIXED: a deposit on the day you attach could trip the drawdown guard
    instantly. The percentage was measured against equity with the day's
    transfers taken out - right for the money figures, wrong as a
    denominator: after a 699.99 deposit that figure read one cent, and one
    cent of float became "max drawdown 66.7%". Seen on a live account on
    1 October; two positions were closed for it. All three percentage limits
    (drawdown, prop daily loss, prop max drawdown) now divide by the real
    account figure. If you deposit and attach on the same day, this build is
    the one you want.

  - ColourTPPips default 300 (was 500) - the target for colour-flip entries.
    Measured over real XAUUSD ticks with the OLD three-session setup (the
    figures for the 10:00-19:00 default are in the first bullet above):
        one month    +63.13, PF 1.41, 73 trades, 82.2% win, 5.44% drawdown
                     (at 500: +58.65, PF 1.43, 71, 83.1%, 5.75%)
        eight months +99.33, PF 1.06, 727 trades, 82.0% win, 25.62% drawdown
                     (at 500: +121.07, PF 1.07, 722, 82.1%, 24.96%)
    Read that honestly: better on the recent month, 21.74 worse over the full
    eight. Set ColourTPPips back to 500 if you prefer the longer-run profile.

  - The AI news row now tells you when it has read a story and found no
    direction. It used to print "-" for that AND for "nothing read yet", so
    since most news is not directional the row sat on "-" almost permanently
    and looked broken. It now reads:
        XAUUSD SELL     a side was called
        XAUUSD mixed    the instrument is clear, the direction is not
        no clear side   a story WAS read and it names no direction
        -               nothing has been read yet
    Expect "no clear side" most of the time and read it as the feature
    working. On the live feed, 2 of the first 25 stories named a tradable
    side. Nothing in the signal path reads this row - it cannot move a trade,
    change a stop or alter a tested figure.
  - New input HotStoryAlert: you are now alerted when a new story arrives.
    "Every new hot story" (the default) announces each one, including the ones
    with no clear side, so you can see the feed working. "Only when a side is
    named" is the quieter choice - roughly one alert every day or two. "Off"
    updates the row silently. It uses your existing PopupAlert / PushAlert /
    TelegramAlert settings, and it has its own alert budget, so it can never
    spend or be blocked by the "ready to trade" hourly cap. One alert per
    story, ever; the story already current when you attach the EA is adopted
    quietly and printed to the Experts log instead of popping an alert about
    old news.
  - Server-side, nothing you need to do. The news reader had a bug that made
    it report a perfectly good AI answer as "empty": the reply arrives as a
    list of blocks and the first block is the model's thinking, not its text,
    and the reader only looked at the first block. That is what froze the row
    for 11h40m on 28 September and nearly blanked it again on 1 October. Fixed
    (server build v8) - every block is read now. Two more guards went in with
    it: a story that still cannot be classified is given up on after two
    attempts instead of being retried every 20 minutes, and the reader's memory
    now survives a site deploy.

  - New shipped defaults: take profit 1200 (was 1500), break-even trigger and
    lock 300 (were 700; the lock now ships as 150, see above), the drawdown
    guard at 16% (was 12%), and the end-of-day flatten off (since removed
    entirely). Measured over real XAUUSD
    ticks against the previous defaults:
        one month   +58.65, PF 1.43, 71 trades, 83.1% win, 5.75% drawdown
                    (previous defaults: +17.32, PF 1.07, 65, 69.2%, 8.21%)
        eight months +121.07, PF 1.07, 722 trades, 82.1% win, 24.96% drawdown
                    (previous defaults: +313.68, PF 1.12, 672, 73.4%, 26.32%)
    Read that honestly: the win rate is much higher and the recent month is far
    stronger, but the tighter target and earlier break-even cut the average win
    from 5.96 to 3.21, and over the full eight months that costs more than it
    saves. If you want the longer-run profile back, set TakeProfitPips to 1500
    and the two break-even values to 700.
  - Positions are not flattened before the end of the day (the flatten was
    switched off on 2026-09-27 and removed from the EA on 2026-10-11).

  - The SIGNAL readiness meter is a real 0-100 reading. It used to score both
    sides from the same three gates and show the higher one, and because those
    two scores are mirror images that always sum to 100, the winning side could
    only ever read 60, 70 or 100 - the bar was never less than 60% full and it
    jumped between three positions. Its two "partial credit" scales were also
    written for a 5-digit FX pair (3 pips and 0.02), which on gold is under a
    cent, so they never did anything. Now the side comes from whichever way the
    Slope line points and all three parts are measured against the instrument's
    own scale: 40% how hard the line is moving, 30% distance from the 50 EMA in
    average bar bodies, 30% MACD against its own recent swing. Over one month of
    real ticks the reading took 94 distinct values across the full range instead
    of 3.
  - ReadinessAlertPct is measured against that meter, so the alert and the bar
    can never disagree. At the shipped 100 the alert now needs the Slope line
    driving as well as the three gates aligned, which is about 23% fewer alerts
    over a month and drops the ones that fired in flat chop. Set it to about 90
    for the old frequency. Note the alert is stricter than the entry, which does
    not require slope movement unless you raise MinTurnMomentumPct - so a trade
    can open on a bar that did not alert.
  - Panel legibility on a small chart. The readiness bar's fill was not being
    scaled with the panel, so on any chart where the panel shrank below 100% the
    bar ran past the right edge - up to 108 px over at the smallest size. Fixed.
    The panel font is now Tahoma rather than Segoe UI, which stays crisp at the
    small sizes a shrunken panel uses, and the smallest size allowed went from
    6pt to 7pt. Buttons are now sized from their own measured label instead of
    fixed widths, so they cannot overlap at any scale, and shorten to
    Pause / Close / Hide if the panel is too narrow for the full words.

  - Closing a basket no longer sends a request the broker would refuse. A
    broker freezes a position while its stop or target sits within its freeze
    distance of the current price; a close attempted in that window fails and
    the terminal logs it. Such a position is now skipped and retried a moment
    later and pending orders are checked the same way. Nothing about how the EA
    enters or exits changed - the same 8-month tick test reproduces the same
    result to the cent.
  - Slope Direction Line period is now 10, not 12. Periods 8 to 16 were each
    run over eight months of real XAUUSD ticks; 10 gave both the best net
    result and the lowest drawdown of the set. The line turns a little sooner,
    so entries come earlier in a move.
  - New optional input MinTurnMomentumPct (default 0 = off). It scores how hard
    the slope line is moving when it turns, 0-100, against its own recent
    movement, and skips turns below the number you set. A flat turn is the line
    wobbling around a level rather than a new leg starting. Try 10 if you want
    fewer, cleaner entries in a ranging market.
  - The dashboard panel has been restyled and now fits any screen. It follows
    your Windows display scaling and, if the chart is too small to hold the
    full panel, shrinks it (down to 55%) instead of running off the edge.
    Resizing the window or moving the chart to another monitor re-fits it
    immediately. DashboardScale overrides the whole thing with a percentage of
    your own.

WHAT IS NEW IN 4.50 (everything since the 4.4x line)
  - No new entries in the last 3 hours of New York (NYLateCutoffHours) or the
    first 2 hours of Tokyo (TokyoOpenSkipHours). Those are the thinnest hours
    of the session and the ones a stop is most often run in. Over eight months
    of real XAUUSD ticks these two filters alone turned the tested result from
    a small loss into a profit, with fewer trades and a lower drawdown.
  - When a colour turn does NOT become a trade, the Experts journal now says
    which gate stopped it - the 50-EMA side test, the chop filter, the MACD
    zero line, the confirmation candle, the daily cap or the news pause. One
    line per bar. "Ready to trade" and "COLOUR FLIP" are alerts, not entries:
    an entry needs a fresh trigger that clears every gate, and it is evaluated
    one bar after the flip because the next candle has to confirm it.
  - Every signal now prints a BUY or SELL label next to its arrow on the chart,
    on the bar that triggered it. Start-up trades and the manual Buy/Sell
    buttons are labelled the same way. Two new inputs control it:
      - ArrowsTakenOnly (true)  mark only trades that actually opened; set it
                                false to mark every signal, filtered ones too
      - ArrowsKeepBars  (200)   redraw the colour turns of the last N closed
                                bars on start-up, so a fresh attach is not an
                                empty chart (0 = only new ones)
    ShowSignalArrows turns all of it off.
  - Telegram alerts are queued and sent by the EA's timer instead of inline, so
    a slow send can no longer delay an entry or a stop move, and the licence
    check backs off while the server cannot be reached. Nothing the EA does on
    a tick waits on the network.
  - Defaults: one entry per signal (UseScaleIn = false), max 14 new trades per
    day, max drawdown 12%. Tested over eight months of real XAUUSD ticks.
  - Stop-width cap (MaxStopPips, with ClampWideStop) is available but ships
    OFF. It does cut the average loss - a 600-pip cap took it from 15.12 to
    6.11 over eight months of real ticks - but it also dropped the win rate
    from 72% to 49%, because this EA's stop already sits at real swing
    structure and tightening it turns winners into losers. Set it only if you
    want a smaller drawdown and accept fewer winners.
  - Stop loss and take profit are now measured against the prices the SERVER
    checks - a buy against the bid, a sell against the ask - plus the minimum
    stop distance of your broker. Before this, a tight setup on a wide spread
    could be refused with "invalid stops" and the trade never opened.
  - Free margin is checked before an order is sent, so an under-funded account
    gets one clear line in the Experts log instead of a run of broker
    rejections. It only blocks a trade when the broker reports a requirement
    larger than your free margin.
  - Deposits and withdrawals no longer affect anything the EA measures. Day
    P&L and drawdown are worked out from the deal history with transfers
    excluded, so moving money in or out is not read as a trading result. The
    previous build could count the same deposit again on every re-attach and
    pause trading on a drawdown that had not happened.
  - The start-up trade only fires on a colour that turned within the last
    3 bars (StartupMaxAgeBars). Attaching the EA no longer opens a trade on a
    colour that turned an hour ago.
  - Licence: demo and real accounts both need activation now, and an account
    that has never verified cannot trade. A previously verified account keeps
    running for 3 days if the licence server cannot be reached. The Strategy
    Tester always runs, so you can still backtest freely.

Included:
  - Gold Scalpers Pro.ex5                        (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers Pro - Quick User Guide.pdf     (setup + all settings)
  - Gold Scalpers Pro - Manual Trading Guide.pdf (trade the strategy yourself, step by step)

Build 2026-09-11 - licence check fixed:
  The EA could not read its own licence-server address (a decoding bug),
  so the check silently passed every real account. It now reaches
  https://goldscalpers.com/licenses.txt as intended. If you never activated,
  your account will now show "License not active": submit your MT5 login on
  https://goldscalpers.com/thank-you-pro (2 minutes) or email support.

What is new in 4.40:
  DEFAULT SETTINGS CHANGED. The EA ships more active than before. If you prefer
  the previous, more selective behaviour, the old values are noted in brackets.

    EntryMode            = Either fires      (was: Slope x EMA cross only)
        BOTH triggers are now live. A slope colour flip and a slope/50-EMA cross
        can each open a trade, whichever comes first, and that trade uses the
        stop and target belonging to the trigger that fired it - the colour-turn
        stop for a flip, the swing stop for a cross. Only one trade runs at a
        time; the two triggers share the single position slot.
    StartupSlopeTrade    = Follow the colour (was: No trade)
        Attaching the EA now OPENS a trade on the colour already showing - green
        a BUY, magenta a SELL. Set it back to "No trade" for alert only.
    SessTokyo            = true              (was: false)
        The Asian session is enabled. It is quieter than London, so the chop
        filter and the confirmation bar carry more of the load there.
    TakeProfitPips       = 1200              (was: 1500)     $12.00 on gold
    BreakEvenPips        = 300               (was: 700)      $3.00 on gold
    BreakEvenLockPips    = 300               (was: 700)
    MaxOpenPositions     = 4                 (was: 3)

  NOTE ON THE BREAK-EVEN LOCK. The EA will not place the locked stop within 80%
  of the trigger, because that puts the stop on top of price and the trade dies
  on the first wiggle. With 300 / 300 the guard caps the lock at HALF the
  trigger - so it runs as 150 - and says so once in the Experts log. That line
  is expected, not a fault. If you want the lock honoured exactly as typed, use
  roughly 20-30% of the trigger - about 60-90 against a 300 trigger.

What was new in 4.30:
  1. STRATEGY PRESETS (the very first input, above everything else).
     The EA can trade two different ways; a preset sets that up in one click.
       - Custom (default)     every input below is used exactly as you set it.
                              Nothing is overridden. Existing setups are unchanged.
       - Colour scalping      trades the GREEN / MAGENTA turns of the Slope line.
                              No MACD wait, no EMA-side rule, no confirmation
                              candle. Stop from the colour turn, target 500.
       - EMA + MACD swing     trades the Slope line crossing the 50 EMA, confirmed
                              by MACD, price on the correct side of the EMA, one
                              confirmation candle. Swing stop, group-3 target.
     A preset NEVER touches risk: lot size, daily limits, the drawdown cap,
     sessions, news and Prop-Firm Mode all stay yours, so either strategy can run
     under prop-firm rules.
     IMPORTANT: a preset wins over the inputs it owns. MetaTrader cannot grey an
     input out, so the pre-flight block in the Experts log lists the active preset
     and every value it changed, and the dashboard header shows the preset name.
     If the header shows a preset, that preset is in charge. Pick Custom to make
     your own inputs win.

  2. COLOUR-TURN ALERTS, every time (not just at start-up).
     The EA now alerts you EVERY time the Slope line changes colour, for as long
     as the chart is open, and the dashboard's "Last signal" row reads
     "Buy Started" or "Sell Started". It reads the last CLOSED candle, never the
     one still forming, because a live candle's slope can flip and flip back.
       - ColourFlipAlert        (true)  alert on every colour change
       - SignalAlertMaxPerHour  (30)    backstop only; 0 = unlimited
     Colour alerts are NEVER delayed by the anti-spam throttle. Alert priority is
     now: risk alerts always, then colour turns, then trade-opened, and only the
     "ready to trade" alert is throttled.

  3. SEPARATE STOP AND TARGET FOR COLOUR ENTRIES (inputs group 0b).
     A colour entry and an EMA-cross entry want different protection, so they get
     it. Colour entries take the stop from the candles AT THE COLOUR TURN plus a
     buffer; EMA-cross entries keep the swing stop. Whichever logic fired the
     trade decides, automatically.
       - ColourTradeOwnRisk (true) colour entries use the stop/target below
       - ColourSLCandles    (3)    candles at the turn that define the stop
       - ColourSLBufferPips (20)   extra room beyond that extreme
       - ColourTPPips       (300)  take profit for colour entries only

  4. FIXES AND TUNING.
     - A new trading day now clears yesterday's max-drawdown pause. Before this,
       an EA left running across midnight could stay locked out of trading even
       though the drawdown baseline had reset.
     - When a trade is skipped, the Experts log now names the exact reason
       (drawdown pause, session, news, spread, daily cap, ...) instead of a vague
       "a filter blocked it".
     - The "ready to trade" alert re-arms on a direction change again, so an
       opposite-side signal is no longer missed.
     - Less wasted work per tick: readiness is computed once per candle instead of
       three times a second, the chart-object sweep is skipped when no pending
       orders exist, and the day's peak equity is persisted at most every 10s.

What was new in 4.20:
  1. START-UP SLOPE SIGNAL (inputs group 0, at the top of the list).
     When you attach the EA it reads the colour the Slope Direction Line is
     drawing right now and alerts you once: GREEN = the line is rising (buy
     side), MAGENTA = falling (sell side). It uses the same rising/falling
     test as the indicator itself, so the alert always matches the line on
     your chart. From the next bar the normal crossover engine takes over.
       - StartupSlopeAlert   (true)            alert the colour on start
       - StartupSlopeTrade   (No trade)        also open a trade on it:
                                               Follow  = green BUY, magenta SELL
                                               Reverse = the opposite
       - StartupSlopeBar     (Last closed bar) which bar the colour is read from
       - StartupTradeFilters (true)            the start-up trade must pass the
                                               normal session / news / spread /
                                               limit filters
     It fires once per attach. Reloading the EA or changing a setting restarts
     it, so the alert comes again - that is the same event, not a new signal.

  2. ANTI-SPAM ALERT THROTTLE (inputs group 8).
     Alerts are now graded. Risk alerts (max drawdown, daily profit target,
     prop-firm breach) are ALWAYS sent. Trade-opened alerts are
     sent unless you switch them off. Informational alerts ("ready to trade",
     start-up slope colour) pass a minimum gap, an hourly ceiling and duplicate
     suppression. A "ready" reading that flipped between buy and sell used to
     re-arm the alert on every bar in a choppy market - that is fixed.
       - AlertOnTradeOpen (true)  alert when the EA opens a trade
       - AlertMinGapSec   (300)   min seconds between info alerts (0 = off)
       - AlertMaxPerHour  (12)    max info alerts per hour (0 = unlimited)
       - AlertRepeatSame  (false) allow the same info alert inside the gap
     Every held-back alert is still written to the Experts journal, so nothing
     disappears silently.

  3. DASHBOARD LAYOUT.
     The manual Buy market / Sell market buttons moved to the TOP of the panel,
     directly under Pause / Close all / Hide Panel, so everything you click is
     together. Session and news (MARKET) moved to the bottom. The new order is
     SIGNAL, control buttons, MANUAL, PERFORMANCE, MARKET. The panel is drawn
     when the EA is attached - remove it from the chart and drag it back on to
     see the new layout.

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers Pro.ex5" there.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M5 chart, drag the EA on, tick "Allow Algo Trading".
     The default settings are already the tuned gold configuration - just click OK.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you-pro) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) scalper on the M5 timeframe. Two triggers can
open a trade and both are live by default (EntryMode = Either): the Slope
Direction Line crossing the 50 EMA, and the Slope line changing direction. Each
one is confirmed by ZeroLag MACD, a chop filter and a confirmation candle. The
stop loss sits at the most recent swing low/high beyond the 50 EMA (real market
structure), with a $15 take-profit and a break-even that locks a winner in
profit.

Out of the box a signal opens ONE market order - no pyramiding. Eight months of
XAUUSD tick testing came out ahead that way, so that is how it ships. These
settings change it:
  - UseScaleIn (default OFF) - Momentum Pyramiding. Turn it on and the EA queues
    add-on stop orders AHEAD of the entry, so they fill only while the move runs
    your way, never by averaging down. Each add-on carries the same stop as the
    first order.
  - AdditionalTrades (default 1, max 30) - how many add-ons are queued, spaced
    PipsInterval apart.
  - TradesPerSignal (default 1, max 10) - open more than one position per
    signal, each with its own stop and target.
  - MaxOpenPositions caps the total either way (0 = no cap).

Sessions: Tokyo, London and New York by default, minus the last 3 hours of New
York (NYLateCutoffHours) and the first 2 hours of Tokyo (TokyoOpenSkipHours).
Optional Prop-Firm Mode enforces %-based daily-loss and max-drawdown limits.

Deposits and withdrawals do NOT count as profit or loss. The day's P&L is added
up from your closed deals with balance operations left out, so a transfer is
invisible to it - there is no baseline to shift and nothing to re-apply when the
EA reloads. Moving cash in or out will not close your open trades or lock the
day. Position sizing still follows the real balance.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
