GOLD SCALPERS EA  -  Download package
=====================================

Included:
  - Gold Scalpers EA.ex5                        (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers EA - Quick User Guide.pdf     (setup + all settings)
  - Gold Scalpers EA - Manual Trading Guide.pdf (trade the strategy yourself, step by step)

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers EA.ex5" there.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M5 chart, drag the EA on, tick "Allow Algo Trading".
     The default settings are already the tuned gold configuration - just click OK.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) scalper on the M5 timeframe - the Slope Direction
Line crossing the 50 EMA (confirmed by ZeroLag MACD). The stop loss sits at the
most recent swing low/high beyond the 50 EMA (real market structure), with
a $5 take-profit and a break-even that locks a winner in profit.

Out of the box the EA takes ONE trade per signal. Two settings change that:
  - UseScaleIn (default OFF) - Momentum Pyramiding. Turn it on and the EA adds
    orders into a WINNING trade as it runs, never averaging down, with a
    step-stop that tightens as each add-on fills. The add-ons carry the same
    stop as the first order.
  - TradesPerSignal (default 1, max 10) - open more than one position per
    signal, each with its own stop and target.
  - MaxOpenPositions caps the total either way (0 = no cap).

Sessions: London and New York by default.
Optional Prop-Firm Mode enforces %-based daily-loss and max-drawdown limits.

Deposits and withdrawals do NOT count as profit or loss. The EA detects the
transfer and shifts its daily-loss, drawdown and profit-target baselines by the
same amount, so moving cash in or out will not close your open trades or lock
the day. Position sizing still follows the real balance.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
