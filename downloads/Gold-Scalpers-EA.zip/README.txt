GOLD SCALPERS EA  -  Download package
=====================================

Included:
  - Gold Scalpers EA.ex5                          (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers EA - XAU Scalp.set              (GOLD, single quick-scalp - recommended)
  - Gold Scalpers EA - XAU Pyramid.set            (GOLD, Momentum Pyramiding / rides winners)
  - Gold Scalpers EA - Major Pairs Scalp.set      (FX pairs, single quick-scalp)
  - Gold Scalpers EA - Major Pairs Pyramid.set    (FX pairs, Momentum Pyramiding)
  - Gold Scalpers EA - Quick User Guide.pdf       (setup + all settings)

WHICH PRESET?
  SCALP   = one entry, a quick take-profit, no add-ons. Simplest, and the
            safest choice for prop-firm accounts. Start here.
  PYRAMID = adds to a WINNING trade as it runs (Momentum Pyramiding), spaced
            automatically by ATR, and rides the move via the step-stop and
            trailing stop (no fixed TP). Bigger swings; best in trends.

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers EA.ex5" there.
     (Optional) copy the .set files into MQL5 > Presets.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M1 chart, drag the EA on, tick "Allow Algo Trading".
     In the EA's inputs, click Load and pick a preset (start with "XAU Scalp").
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) M1 scalper - the Slope Direction Line crossing the
50 EMA (confirmed by ZeroLag MACD), a protective step-stop and a trailing stop.
In Pyramid mode it adds to winners only (never averages down); add-on spacing is
set by ATR (AtrSpacingMult x ATR) so it scales to gold vs FX and to each session.
It also runs on major FX pairs (use the Major Pairs presets).

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
