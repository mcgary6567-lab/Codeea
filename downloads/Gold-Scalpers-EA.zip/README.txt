GOLD SCALPERS EA  -  Download package
=====================================

Included:
  - Gold Scalpers EA.ex5                        (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers EA - XAUUSD.set               (GOLD preset)
  - Gold Scalpers EA - Other Pairs.set          (FX majors preset)
  - Gold Scalpers EA - Quick User Guide.pdf     (setup + all settings)

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers EA.ex5" there.
     (Optional) copy the two .set files into MQL5 > Presets.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M1 chart, drag the EA on, tick "Allow Algo Trading".
     In the EA's inputs, click Load and pick "XAUUSD" (or "Other Pairs" for FX).
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) M1 scalper - the Slope Direction Line crossing the
50 EMA (confirmed by ZeroLag MACD), a protective step-stop and a trailing stop.

Momentum Pyramiding: by default it adds up to 2 orders into a WINNING trade as it
runs (never averages down), spaced by a fixed PipsInterval set per instrument.
  OPTIONAL - ATR auto-spacing: set UseAtrSpacing = true and the add-on gap becomes
  AtrSpacingMult x ATR, so it auto-scales to the pair and to calm vs volatile
  sessions (widens the gap in fast markets). Leave it off to use the fixed
  PipsInterval. Either way the gap is floored at the broker's minimum stop distance.
Turn UseScaleIn off for a single entry with no add-ons. Runs on major FX pairs too.

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
