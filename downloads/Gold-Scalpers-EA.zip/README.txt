GOLD SCALPERS EA  -  Download package
=====================================

Included:
  - Gold Scalpers EA.ex5                        (the Expert Advisor for MetaTrader 5)
  - Gold Scalpers EA - XAU.set                  (XAUUSD / gold preset - recommended)
  - Gold Scalpers EA - Major Pairs.set          (major FX pairs preset)
  - Gold Scalpers EA - Quick User Guide.pdf     (setup + all settings)

Quick setup:
  1. In MT5: File > Open Data Folder > MQL5 > Experts. Copy "Gold Scalpers EA.ex5" there.
     (Optional) copy the two .set files into MQL5 > Presets.
  2. Restart MT5. The EA appears under Navigator > Expert Advisors.
  3. Open a XAUUSD M1 chart, drag the EA on, tick "Allow Algo Trading".
     In the EA's inputs, click Load and choose "Gold Scalpers EA - XAU" to load the gold preset.
  4. LICENCE (required): MT5 > Tools > Options > Expert Advisors >
     tick "Allow WebRequest for listed URL" and add EXACTLY:
         https://goldscalpers.com
     (add https://api.telegram.org too if you use Telegram alerts)
     Note: the "License_URL" input in the EA is READ-ONLY - it just shows you which
     URL to allow here. You do not need to change it.
  5. Activate your licence: submit your MT5 account number on the thank-you page
     (https://goldscalpers.com/thank-you) - it is authorized automatically within
     ~2 minutes. Or email it to support@goldscalpers.com.

Strategy: a pure XAUUSD (gold) M1 scalper - the Slope Direction Line crossing the
50 EMA (confirmed by ZeroLag MACD), with an AutoScaler grid, quick scalping take-profit
and a step-stop trail. It also runs on major FX pairs (use the Major Pairs preset).

Full instructions: open the Quick User Guide PDF.
Support: support@goldscalpers.com
Trading is high-risk. Test on a demo account and backtest before going live.
